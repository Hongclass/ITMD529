library(plyr)
library(dplyr)
library(wordcloud)
library(RColorBrewer)
library(lubridate)                                                         # Loading CRAN package for Calendar purposes
library(ggplot2)
library(ggrepel)
library(party)

colnames(x)
getwd()
setwd("C:/Users/haqna/Desktop/Fall 2016/ITMD 529/Week/Mid term Project/R Scripts")

Input <- read.csv("Merged.csv")
x <- data.frame(Input)

names(x)[95] <- "Alzheimer"
names(x)[96] <- "Heart Failure"
names(x)[97] <- "Kidney"
names(x)[98] <- "Cancer"
names(x)[99] <- "Pulmonary"
names(x)[100] <- "Depression"
names(x)[101] <- "Diabetes"
names(x)[102] <- "Ischemic Heart"
names(x)[103] <- "Osteoporosis"
names(x)[104] <- "Arthritis/Osteoarthritis"
names(x)[105] <- "Stroke"

result <- colSums(x[,95:105])
Medical_Condition <- data.frame(Disease = names(result), Freq = result, stringsAsFactors  = F)

pal <-brewer.pal(8,"Reds")
wrdcld <- wordcloud(words = Medical_Condition$Disease, Medical_Condition$Freq, 
                    scale=c(3,0.7),
                    colors=pal)


x[ , 95:105 ][ x[ , 95:105 ] == 1 ] <- "Yes"
x[ , 95:105 ][ x[ , 95:105 ] == 2 ] <- "No"
sapply(x[95:105], function(y) unique(y))
sapply(x[95:105], function(y) unique(y))

###--------------Gender value Change------------------###

which(colnames(x)=="BENE_SEX_IDENT_CD")

x[ , 86 ][ x[ , which(colnames(x)=="BENE_SEX_IDENT_CD") ] == 1] <- "Male"
x[ , which(colnames(x)=="BENE_SEX_IDENT_CD") ][ 
     x[ , which(colnames(x)=="BENE_SEX_IDENT_CD") ] == 2] <- "Female"

#---------------------------------------------------------------- Length of Stay ----------------------------------------------------------------#

admsn_dt <- ymd(x$CLM_ADMSN_DT)                                            # Converting to date format - Specific to the input
dschrg_dt <- ymd(x$NCH_BENE_DSCHRG_DT)
x$length_stay <- (difftime(dschrg_dt, admsn_dt, units = "days"))+1         # +1 Denotes one day length of stay if same day discharge
table(x$length_stay)                                                       # Length of Stay Calculation (Admission Date to Discharge Date)

#------------------------------------------------------------- Length of Stay Plot --------------------------------------------------------------#

grp_stay <- data.frame(table(x$length_stay))                               # Length of stay frequency tabulation 
colnames(grp_stay)
plot(grp_stay$Freq, type = "o", xlab = "Length of Stay in number of days", 
     ylab = "Number of Inpatients", main = "Length of Stay - Inpatients"
     ,col="red", pch =1)  # Plotting Number of Patients versus Length of Stay
mean(x$length_stay)

#-------------------------------------------------------------- Race of Patients ---------------------------------------------------------------#

which(colnames(x)=="BENE_RACE_CD")  #87
x$BENE_RACE_CD [x$BENE_RACE_CD == 1] <- "White"
x$BENE_RACE_CD [x$BENE_RACE_CD == 2] <- "African-American"
x$BENE_RACE_CD [x$BENE_RACE_CD == 3] <- "Others"
x$BENE_RACE_CD [x$BENE_RACE_CD == 5] <- "Hispanic"

#-------------------------------------------------------------- Pie Charts ---------------------------------------------------------------#

table(x$BENE_RACE_CD)                                                      # Summary by Race
df_race <- data.frame(prop.table(table(x$BENE_RACE_CD)))
piepercent_race<- paste(round(100*df_race$Freq/sum(df_race$Freq), 1), "%")
pie(df_race$Freq, paste(piepercent_race),                                  # Plotting Race pie Chart with legends
    main = "Inpatient By Ethnicity", col = c("Yellow2","Green","Brown3", "deepskyblue3"))
legend("right", as.vector(df_race$Var1), cex = 0.8, fill = c("Yellow2","Green","Brown3", "deepskyblue3"))

table(x$BENE_SEX_IDENT_CD)                                                 # Summary by Sex                                         
df_sex <- data.frame(prop.table(table(x$BENE_SEX_IDENT_CD)))               
piepercent_sex<- paste(round(100*df_sex$Freq/sum(df_sex$Freq), 1), "%")
pie(df_sex$Freq, paste(piepercent_sex),                                    # Plotting Gender pie Chart with legends
    main = "                  Inpatient Count By Gender", col = c("tomato","tomato4"))
legend("right", as.vector(df_sex$Var1), cex = 0.8, fill = c("tomato","tomato4"))

#-------------------------------------------------------------- Age ---------------------------------------------------------------#

age = function(birth_date, comp_day) {                                     # Function age to estimate the age of inpatients
  birth_lt = as.POSIXlt(ymd(birth_date))
  comp_lt = as.POSIXlt(ymd(comp_day))
  age = comp_lt$year - birth_lt$year                                      # Logic to incorporate leap year
  ifelse(comp_lt$mon < birth_lt$mon |
           (comp_lt$mon == birth_lt$mon & comp_lt$mday < birth_lt$mday),
         age - 1, age)
}

x$AGE <- age(x$BENE_BIRTH_DT, x$NCH_BENE_DSCHRG_DT)                       # Age of inpatients on discharge date
prxy_death <- which(!is.na(x$BENE_DEATH_DT))                              # For deceased patients age estimated till death date
x$AGE[prxy_death]  <- age(x$BENE_BIRTH_DT[prxy_death], x$BENE_DEATH_DT[prxy_death])
x$AGE

#------------------------------------------------------------Death_Ind------------------------------------------------------------------#

x$Death_Ind <- 1
x$Death_Ind[which(is.na(x$BENE_DEATH_DT))] <- 0
table(x$Death_Ind)

#---------------------------------------------------------------------------------------------------------------------------------------#
Deaths <- x[x$Death_Ind ==1,]
Discharged <- x[x$Death_Ind ==0,]
nrow(Deaths)
# PARTY package
y <- data.frame(x, StringAsFactors = T)

z <- data.frame(x$CLM_PMT_AMT,x$Age,x$length_stay)
ncol(z)
colnames(z) <- c("Claim_Payment", "Age", "Length_Stay")
z <- setNames(z, c("Claim_Payment", "Age", "Length_Stay"))

x$length_stay <- as.integer(y$length_stay)
which(names(x) %in% "sex")
which(names(x) == "AGE")
which(names(x) == "CLM_PMT_AMT")
col(x, as.factor = FALSE)
x$length_stay <- as.integer(y$length_stay)
Length_Stay <- x$length_stay

ct = ctree(y$Death_Ind ~ as.integer(y$AGE) + Length_Stay , data = y)


plot(ct,type="simple",title = "Ctree - Claim Amount($), Length Of Stay(days) & Age(Years)" ,          # no terminal plots
     inner_panel=node_inner(ct,
                            abbreviate = F,            # short variable names
                            fill = c("Brown2"),
                            pval = FALSE,                 # no p-values
                            id = FALSE),                  # no id of node
     terminal_panel=node_terminal(ct, 
                                  abbreviate = F,
                                  digits = 1,                   # few digits on numbers
                                  fill = c("Brown"),            # make box white not grey
                                  id = FALSE))


#----------------------------------------------------------------#

